using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PersistentData : IPersistentData
{
    public PlayerData PlayerData { get; set; }
}
