public class IntValueView : ValueView<int>
{
    public void SetValue(int value) => Show(value);
}